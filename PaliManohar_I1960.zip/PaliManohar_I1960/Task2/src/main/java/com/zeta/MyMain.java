package com.zeta;
/*
 * Author: Pali Manohar
 * EmployeeId: I1960
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;
/*
 * This is the dispatch servlet
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class })
public class MyMain {
	public static void main(String[] args) {
		SpringApplication.run(MyMain.class, args);
	}
	@Bean
	// to call restTemplate
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
