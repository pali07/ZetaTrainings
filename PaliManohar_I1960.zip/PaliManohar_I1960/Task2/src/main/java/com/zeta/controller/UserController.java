package com.zeta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.model.Data;
import com.zeta.model.Indexdata;
import com.zeta.service.Serviceimpl;
/*
 * This is the implementation of controller 
 */
@RestController
public class UserController {

	@Autowired
	Serviceimpl service;
	//This is Mapping to getalltheusers
	@RequestMapping(value = "/users", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Data getAllUsers() {
		return service.getAllUsers();
	}
	//This is Mapping to gettheuserbyId
	@RequestMapping(value = "/users/{id}", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Indexdata getUserById(@PathVariable int id) {
		return service.getUserById(id);
	}
	//This is Mapping to getthepagenumber
	@RequestMapping(value = "/users/page/{page}", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Data getByPage(@PathVariable int page) {
		return service.getByPage(page);
	}
}