package com.zeta.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zeta.model.Data;
import com.zeta.model.Indexdata;
/*
 * Implementation of IService interface
 */
@Service
public class Serviceimpl implements IService {

	@Autowired
	RestTemplate template;

	public Data getAllUsers() {
		
		//  function to getAllUsers using rest template
		

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET, entity,
					Data.class);

			Data dt = (Data) response.getBody();
			return dt;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Indexdata getUserById(int id) {
		
		 // function to getUserdetails by id using rest template
		
		String url = "https://reqres.in/api/users/{id}";
		url = url.replace("{id}", String.valueOf(id));

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET, entity, Indexdata.class);

			System.out.println(response);
			Indexdata dt = (Indexdata) response.getBody();
			return dt;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public Data getByPage(int page) {
		
		 // function to getUserdetails by id using rest template
		
		String url = "https://reqres.in/api/users?page={id}";
		url = url.replace("{id}", String.valueOf(page));
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET, entity, Data.class);

			System.out.println(response);
			Data  dt = (Data) response.getBody();
			return dt;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

}