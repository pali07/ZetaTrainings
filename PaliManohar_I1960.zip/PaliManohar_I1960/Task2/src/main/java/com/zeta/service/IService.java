package com.zeta.service;

import java.util.List;

import com.zeta.model.Data;
import com.zeta.model.Indexdata;
/*
 * This related to Service interface contains methods 
 */
public interface IService {
	public Data getAllUsers();
	public Indexdata getUserById(int id);
	public Data getByPage(int page);
}
