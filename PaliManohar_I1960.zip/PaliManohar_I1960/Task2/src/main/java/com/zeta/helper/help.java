package com.zeta.helper;
import org.apache.log4j.Logger;
public class help {
	public static Logger getLog(Class s){		// TODO Auto-generated method stub
		Logger lg = Logger.getLogger(s);
		return lg;
	}

}