package com.zeta.model;

import com.fasterxml.jackson.annotation.JsonProperty;
/*
 * This related to userdata+supportdata+
 */
public class Indexdata {
	@JsonProperty("data")
	private UserData data;
	@JsonProperty("support")
	private SupportData text;
	public UserData getData() {
		return data;
	}
	public void setData(UserData data) {
		this.data = data;
	}
	public SupportData getText() {
		return text;
	}
	public void setText(SupportData text) {
		this.text = text;
	}
}
