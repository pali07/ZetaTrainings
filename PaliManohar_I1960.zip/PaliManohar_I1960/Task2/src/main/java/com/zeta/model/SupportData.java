package com.zeta.model;

import com.fasterxml.jackson.annotation.JsonProperty;
/*
 * This related to support data
 */
public class SupportData {
	@JsonProperty("url")
	private String url;
	@JsonProperty("text")
	private String text;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
}
