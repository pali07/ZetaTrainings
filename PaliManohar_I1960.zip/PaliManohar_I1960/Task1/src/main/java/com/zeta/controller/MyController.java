package com.zeta.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.model.LoanDetails;
import com.zeta.service.IMyservice;
/*
      This is controller to implement the endpoints
*/
@RestController
public class MyController {
	@Autowired
	IMyservice service;
	@RequestMapping("/zeta/all")
	public List<LoanDetails> getLoan(){
		//help.getLog(MyController.class).info(this.getClass().getSimpleName() +" getting All Employess...");

		//  function to get all the loandetails
		
		return service.getAllLoanHolderDetails();
	}
	@RequestMapping("/zeta/getone/{id}")
	public LoanDetails getOne(@PathVariable int id) throws Exception{
		
		// function to get all the loandetails by loanid
		 
	//	help.getLog(MyController.class).info("getting Loan with id.."+id);
		return service.getByLoanId(id);
	}
	@PostMapping("/zeta/addLoan")
	public LoanDetails addLoan(@RequestBody LoanDetails ld){
	//	help.getLog(MyController.class).info("adding Loan...");
		
		//  function to add new loan to the DB
		 
		return service.addLoanHolder(ld);
	}
	@PutMapping("/zeta/update/{id}")
	public LoanDetails update(@RequestBody LoanDetails ld,@PathVariable int id){
		LoanDetails l = service.getByLoanId(id);
		ld.setloannumber(id);
		
		// function to update loan details
		 
		//help.getLog(MyController.class).info("updating Loan details with id..."+id);
		return service.updateLoan(ld);
	}
	@DeleteMapping(value= "/zeta/delete/{id}")
	public void deleteLoanById(@PathVariable int id) throws Exception {
	//	help.getLog(MyController.class).info("delete Loan with id..."+id);
	
		// function to delete loan holder 
		 
		service.deleteByLoanId(id);
	}

	@DeleteMapping(value= "/zeta/deleteall")
	public void deleteAll() {
		
		//  function to delete all the data
		
	//	help.getLog(MyController.class).info("deleting all the loan details...");
		service.deleteAll();
	}
	
}
