package com.zeta;
/*
 * Author: Pali Manohar
 * EmployeeId: I1960
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
/*
this is main function where we have to run 
*/
@SpringBootApplication
@EnableSwagger2
public class MyMain {
	public static void main(String[] args) {
		
		SpringApplication.run(MyMain.class,args);
	}
}
