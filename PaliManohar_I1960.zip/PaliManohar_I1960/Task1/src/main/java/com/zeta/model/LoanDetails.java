package com.zeta.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
/*
 * This is the model class to connect with Mysql table
 */
@Table(name = "loanaccount1")
@Entity
public class LoanDetails {
	@Id
	private int loanNumber;
	@Column
	private String aadharNumber;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private double loanAmount;
	@Column
	private Date loanStartDate;
	@Column
	private double tenure;

	public int getloannumber() {
		return loanNumber;
	}

	public void setloannumber(int loannumber) {
		this.loanNumber = loannumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Date getLoanStartDate() {
		return loanStartDate;
	}

	public void setLoanStartDate(Date loanStartDate) {
		this.loanStartDate = loanStartDate;
	}

	public double getTenure() {
		return tenure;
	}

	public void setTenure(double tenure) {
		this.tenure = tenure;
	}

}
