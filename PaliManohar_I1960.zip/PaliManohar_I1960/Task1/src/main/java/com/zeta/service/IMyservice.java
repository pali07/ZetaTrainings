package com.zeta.service;

import java.util.List;

import com.zeta.model.LoanDetails;
/*
 *  This is Myservice interface which contains CRUD operations
 */
public interface IMyservice {
	public List<LoanDetails> getAllLoanHolderDetails();
	public LoanDetails getByLoanId(int loanId);
	public LoanDetails addLoanHolder(LoanDetails ld);
	public LoanDetails updateLoan(LoanDetails ld);
	public void deleteByLoanId(int loanId);
	public void deleteAll();
	
}
