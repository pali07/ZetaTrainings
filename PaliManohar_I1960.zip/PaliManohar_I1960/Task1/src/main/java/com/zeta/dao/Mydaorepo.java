package com.zeta.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zeta.model.LoanDetails;
/*
  This is DAOrepo interface to extends Jpa repository
 */
@Repository
public interface Mydaorepo extends JpaRepository<LoanDetails, Integer> {

}
