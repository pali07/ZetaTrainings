package com.zeta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.dao.Mydaorepo;
import com.zeta.model.LoanDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

/*
 *  This is implementation for Myservice */
@Service
public class Myserviceimpl implements IMyservice {
	@Autowired
	Mydaorepo dao;

	public List<LoanDetails> getAllLoanHolderDetails() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	public LoanDetails getByLoanId(int loanId) {
		// TODO Auto-generated method stub
		return dao.findOne(loanId);
	}

	public LoanDetails addLoanHolder(LoanDetails ld) {
		// TODO Auto-generated method stub
		dao.save(ld);
		return ld;
	}

	public LoanDetails updateLoan(LoanDetails ld) {
		// TODO Auto-generated method stub
		dao.save(ld);
		return ld;
	}

	public void deleteByLoanId(int loanId) {
		// TODO Auto-generated method stub
		dao.delete(loanId);
		
	}


	public void deleteAll() {
		// TODO Auto-generated method stub
		dao.deleteAll();
	}

}
