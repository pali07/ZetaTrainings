package com.zeta.test;

import static org.junit.Assert.*;
import java.sql.Date;
import java.util.List;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.jupiter.api.*;
import com.zeta.dao.Mydaorepo;
import com.zeta.model.LoanDetails;
import com.zeta.service.IMyservice;
/*
 * This is the class to test for website
 */
@RunWith(SpringRunner.class)
@SpringBootTest
// @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@FixMethodOrder()
public class SpringBootJunittest {
	@Autowired
	private Mydaorepo repo;
	@Autowired
	private IMyservice service;

	@Test
	@Order(1)
	public void getLoanDetailsTest() {
		// List<LoanDetails> list = repo.findAll();
		List<LoanDetails> list = service.getAllLoanHolderDetails();
		assertEquals(1, list.size());
	}

	@Test
	@Order(2)
	public void addNewLoanTest() {
		LoanDetails l = new LoanDetails();
		l.setloannumber(109);
		l.setAadharNumber("071404316348");
		l.setFirstName("manohar");
		l.setLastName("pali");
		l.setLoanAmount(2344.90);
		l.setLoanStartDate(new Date(2024 - 02 - 03));
		l.setTenure(2.7);
		repo.save(l);
		// assertNotNull(repo.findOne(109));
		assertNotNull(service.getByLoanId(109));
	}

	@Test
	@Order(3)
	public void getLoanByIdTest() {
		// LoanDetails l = repo.findOne(1002);
		LoanDetails l = service.getByLoanId(1002);
		assertEquals(5.0, l.getTenure(), 0.0);
	}

	@Test
	@Order(4)
	public void updateLoanTest() {
		// LoanDetails l = repo.findOne(1002);
		LoanDetails l = service.getByLoanId(1002);
		l.setLoanAmount(2222.22);
		repo.save(l);
		assertNotEquals(82000.91, l.getLoanAmount());
	}

	@Test
	@Order(5)
	public void deleteLoanByIdTest() {
		// repo.delete(109);
		service.deleteByLoanId(109);
		assertEquals(false, repo.exists(109));
	}
}